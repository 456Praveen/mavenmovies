SELECT 
count(distinct category_id)
from film_category;