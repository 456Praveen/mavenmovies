SELECT 
distinct title,
max(replacement_cost)
from film
group by title
order by max(replacement_cost) desc 
limit 1;