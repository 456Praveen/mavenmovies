select
distinct title,
avg(replacement_cost)
from film
group by title
order by avg(replacement_cost) asc ;