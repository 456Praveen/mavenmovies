SELECT
count(distinct email)
from customer ;