SELECT 
store_id,
count(inventory_id)
from
inventory
where store_id =2
group by store_id;