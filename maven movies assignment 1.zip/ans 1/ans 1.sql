SELECT
staff_id,
first_name,
last_name,
email,store_id,
address_id
from
staff;