select
store_id
,count(distinct film_id)
from inventory
group by store_id;
