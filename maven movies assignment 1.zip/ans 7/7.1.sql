SELECT 
distinct rental_id as p,
max(amount)
from payment
group by p
order by max(amount) desc
limit 1;