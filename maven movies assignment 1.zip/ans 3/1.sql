SELECT 
store_id,
count(customer_id)
from customer
where active =1
group by store_id
having store_id =2;