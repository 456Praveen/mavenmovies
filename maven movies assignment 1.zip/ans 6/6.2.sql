SELECT 
distinct title,
min(replacement_cost)
from film
group by title
order by min(replacement_cost) asc 
limit 1;